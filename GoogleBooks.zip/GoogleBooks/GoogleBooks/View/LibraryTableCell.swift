//
//  LibraryTableCell.swift
//  GoogleBooks
//
//  Created by Consultant on 10/27/19.
//  Copyright © 2019 J M. All rights reserved.
//

import UIKit

class LibraryTableCell: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    

}
