//
//  GoogleCoreManager.swift
//  GoogleBooks
//
//  Created by Consultant on 10/27/19.
//  Copyright © 2019 J M. All rights reserved.
//


import UIKit

let core = GoogleCoreManager.shared

final class GoogleCoreManager {
    
    static let shared = GoogleCoreManager()
    private init() {}
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    lazy var persistentContainer: NSPersistentContainer = {
        var container = NSPersistentContainer(name: "Google Books")
        
        container.loadPersistentStores(completionHandler: { (storeDescrip, err) in
            if let error = err {
                fatalError(error.localizedDescription)
            }
        })
        
        return container
    }()
}
